# Szkoła trenerów — Akademia gry (wersja 1.7)

Responsywna, edukacyjna aplikacja webowa w języku polskim dla trenerów piłkarskich. Tryb lokalny działa bez konta; logowanie, rejestracja, reset hasła i synchronizacja między urządzeniami wymagają skonfigurowanego projektu Supabase i uruchomienia strony pod adresem HTTP/HTTPS.

## Uruchomienie

**Tryb lokalny:** rozpakuj archiwum i otwórz `index.html` w nowoczesnej przeglądarce.

**Tryb kont (wymagany):** uruchom stronę przez HTTP/HTTPS, nie `file://`. Do lokalnych testów w folderze `szkola-trenerow` uruchom:

```bash
python -m http.server 8080
```

Następnie otwórz `http://localhost:8080`.

## Co zawiera wersja 1.7

- Panel główny z postępem nauki i zadaniami do wykonania.
- 10 lekcji: model gry, budowanie od bramki, pressing, przejścia, atak pozycyjny, mikrocykl, skauting, rozwój zawodników, stałe fragmenty i coaching.
- Quiz do każdej lekcji z informacją zwrotną i możliwością oznaczenia lekcji jako ukończonej.
- 29 rozbudowanych studiów przypadków: Guardiola, Klopp, Ancelotti, Simeone oraz profile związane z czołowymi klubami, m.in. Arsenalem, Barceloną, Bayernem, Liverpoolem, PSG, Interem, Dortmundem i Realem. Każde studium zawiera analizę mechanizmów, ryzyk, kontrrozwiązań, pytanie i zadanie praktyczne.
- Interaktywna tablica taktyczna z ustawieniami 4-3-3, 3-2-2-3, 4-4-2, 4-2-3-1, 3-5-2 i 3-4-2-1; można dodawać, przeciągać i ustawiać zawodników oraz rysować strzałki. Ostatni rysunek i rozpoczęte zadanie można odtworzyć po odświeżeniu.
- Edytor mikrocyklu meczowego i konstruktor jednostki treningowej.
- Raport skautingowy rywala z checklistą.
- Profile rozwojowe zawodników.
- Edytor filozofii gry, wartości oraz dziennik refleksji.
- Eksport notatek i wybranych danych do plików tekstowych.
- Układ dopasowany do ekranów desktopowych i telefonów.
- Jasny motyw akademicki: białe karty, jasne tła, mocniejszy kontrast tekstu i niebieskie akcenty.
- Czytelniejsze treści lekcji i formularze, z większym rozmiarem tekstu w kluczowych miejscach.
- Wygodniejsze menu mobilne z zamykaniem przez dotknięcie tła.
- Usunięta powielona obsługa klawisza Enter w wyszukiwarce.
- Mapa czterech etapów kompetencji z postępem i filtrowaniem lekcji na etap; oznaczenia C/B/A/Pro są wyłącznie inspiracją dydaktyczną.
- Karta pracy w każdej lekcji: odpowiedź praktyczna, cztery kryteria samooceny w skali 0–2, informacja zwrotna do autorefleksji i automatyczny zapis szkicu.
- Warunek ukończenia lekcji łączy zaliczenie quizu z zapisaniem zadania praktycznego.
- Studia przypadków trenerów mają pola na własną obserwację, decyzję, reakcję rywala i transfer do treningu; dane można eksportować oraz przenosić do dziennika.
- Profile zawodników obsługują kolejne przeglądy rozwoju, kontekst obserwacji, notatkę dowodową, następny krok i porównanie ocen z poprzednim przeglądem.

## Ważne rozróżnienie

To materiał edukacyjny i warsztat do samodzielnej nauki. Nie jest oficjalnym kursem ani certyfikatem UEFA/PZPN i nie zastępuje praktyki, mentoringu lub wymogów federacji. Wymogi kursów oraz ścieżki licencyjne należy potwierdzać u właściwej federacji.

## Prywatność i ograniczenia

- Bez skonfigurowanego Supabase aplikacja działa w trybie lokalnym; dane pozostają w pamięci przeglądarki na danym urządzeniu.
- Po konfiguracji Supabase logowanie/rejestracja i reset hasła są obsługiwane przez Supabase Auth, a warsztat użytkownika synchronizuje się w tabeli `user_workspaces` chronionej RLS.
- Klucz `anon/public` jest przeznaczony do klienta przeglądarkowego, ale nie należy nigdy umieszczać w projekcie klucza `service_role`. Bezpieczeństwo dostępu do danych zapewniają polityki RLS w `supabase/schema.sql`.
- Samoocena zadań (0–8) jest narzędziem refleksji użytkownika, a nie obiektywną oceną ekspercką ani oficjalną oceną kursową.
- Wyczyść dane witryny/przeglądarki, aby usunąć lokalny postęp i notatki. Warto regularnie eksportować ważne materiały.
- Czcionki Google są opcjonalnym dodatkiem wizualnym. Gdy nie ma połączenia z Internetem, zostanie użyta czcionka systemowa.
- Treści taktyczne są materiałem szkoleniowym, a nie sztywną receptą. Wybór rozwiązania zależy od poziomu, wieku, profilu zawodników, rywala i kontekstu meczu.

## Źródła i dalsza lektura

- UEFA, *UEFA coaching licences*: https://www.uefa.com/development/coaches/uefa-coaching-licences/
- UEFA, analiza budowania gry Manchesteru City przeciw 4-4-2 Realu Madryt: https://www.uefa.com/uefachampionsleague/news/028c-1ab88d1dbff7-a3a7970115ff-1000--champions-league-performance-insights-the-importance-of-in-/
- Premier League, *How Guardiola and Klopp's tactics have continuously evolved*: https://www.premierleague.com/en/news/3791815
- UEFA, *UEFA Coaching Convention 2025*: https://documents.uefa.com/api/khub/documents/wy9vGhmNiib2WOQk1txZxg/content

- Biblioteka 24 studiów przypadków z wyszukiwaniem po trenerze, klubie i mechanizmie gry.
- Każde studium ma pięć wymiarów analizy, pytanie decyzyjne i zadanie do przełożenia na trening.
- Profile klubów i trenerów są materiałem edukacyjnym; nie stanowią obiektywnego rankingu klubów. Sprawdź aktualny okres zatrudnienia przed analizą konkretnego meczu.


## Biblioteka analiz trenerów

Biblioteka zawiera 29 autorskich studiów dydaktycznych. Wśród dodanych profili: Andoni Iraola, Xabi Alonso, Liam Rosenior, Enzo Maresca i Simone Inzaghi; rozbudowane profile obejmują również Thomasa Tuchela, José Mourinho i Roberto De Zerbiego. To syntezy szkoleniowe, a nie oficjalne raporty klubów ani analiza jednego konkretnego meczu. Zweryfikuj zachowania w nagraniu i kontekście sezonu przed użyciem ich jako wniosków meczowych.


## Aktualizacja analiz 1.4

Rozszerzono osiem studiów taktycznych: Andoni Iraola, Xabi Alonso, Roberto De Zerbi, Thomas Tuchel, José Mourinho, Liam Rosenior, Enzo Maresca i Simone Inzaghi. Każde zawiera omówienie struktury/formacji, budowania gry, ataku w ostatniej tercji, obrony i pressingu, obu faz przejściowych, ryzyk oraz zadania treningowego. Są to syntezy edukacyjne; konkretne zachowania należy weryfikować na nagraniach danego meczu i sezonu.


## Testy kompetencji taktycznych — 1.5

- Każde z 29 studiów przypadku ma własny, zwijany test: trzy pytania wielokrotnego wyboru zbudowane z treści konkretnej analizy, wyjaśnienie odpowiedzi i odniesienie do odpowiedniej sekcji profilu.
- Po quizie trener pisze krótkie uzasadnienie decyzji. Informacja zwrotna sprawdza obecność sygnału/kontekstu, opisu mechanizmu/przestrzeni, ryzyka/zabezpieczenia oraz wystarczającej treści.
- Z każdego studium można przejść do zadania na tablicy taktycznej z rekomendowaną strukturą, przesuwaniem zawodników, rysowaniem strzałek i polem na uzasadnienie.
- Ocena tablicy weryfikuje kompletność pracy (zmiana pozycji, co najmniej dwie strzałki, uzasadnienie i odniesienie do ryzyka). Nie jest automatyczną oceną jakości taktycznej ustawienia. Automatyczna ocena odpowiedzi tekstowej jest rubryką/heurystyką słów, a nie oceną ekspercką ani modelem językowym.
- Wyniki quizów, odpowiedzi i oceny zadań na tablicy zapisują się lokalnie w przeglądarce. Nie synchronizują się między urządzeniami.


## Naprawy i ulepszenia — 1.6

- Naprawiono renderowanie nazw i priorytetów dni mikrocyklu jako niezaufanego tekstu; wartości obciążenia są ograniczone do zakresu 0–100.
- Odpowiedź tekstowa w analizach jest oceniana jako jawna checklista kompletności sygnału, mechanizmu, ryzyka i spójności. Powtarzanie kilku haseł nie daje już automatycznie 4/4; to nadal regułowa wskazówka, nie ekspercka ocena taktyczna.
- Ponowienie quizu rozpoczyna pustą próbę, a poprzedni wynik pozostaje w lokalnej historii. Wyniki quizów lekcji są odtwarzane po ponownym otwarciu.
- Tablica zapisuje pełny układ zawodników, strzałki, bazową formację i aktywne zadanie. Kontrola kompletności uwzględnia relacje strzałek do znaczników zawodników i uczciwie opisuje ograniczenia automatycznego sprawdzania.
- Mapowanie formacji jest jawne dla wszystkich 29 studiów; dodano presety 4-2-3-1, 3-5-2 i 3-4-2-1. Są to punkty wyjścia do ćwiczeń, nie twierdzenie o stałej formacji trenera.
- Wyszukiwarka globalna uwzględnia kluby, zadania, pytania i źródła, a wynik otwiera właściwe studium. Filtr biblioteki analiz zachowuje stan po ponownym renderze.
- Biblioteka 29 analiz jest zwijana, by ułatwić przeglądanie na telefonie; otwarte studium pozostaje otwarte po zapisie i sprawdzeniu quizu.
- Strzałki można rozpoczynać i kończyć na znacznikach zawodników.

Dane nadal pozostają lokalnie w przeglądarce. W tej wersji nie ma kont ani synchronizacji między urządzeniami.


## Konta użytkowników i synchronizacja — konfiguracja

Funkcje kont zostały przygotowane w `auth.js`. Do ich uruchomienia potrzebny jest własny projekt Supabase; w repozytorium nie ma prawdziwych kluczy ani haseł.

1. Utwórz projekt na https://supabase.com/.
2. W `Project Settings → API` skopiuj **Project URL** i **anon/public key**.
3. Wstaw te dwie wartości do `supabase-config.js`. To jedyny plik konfiguracyjny klienta; nie umieszczaj tu `service_role`.
4. W Supabase → **SQL Editor** uruchom cały plik `supabase/schema.sql`. Tworzy on tabelę na dane warsztatu i włącza polityki Row Level Security, które pozwalają użytkownikowi odczytać i zmieniać wyłącznie własny rekord.
5. W Supabase → **Authentication → URL Configuration** ustaw Site URL na adres strony oraz dodaj ten adres do Redirect URLs. Dodaj też lokalny adres testowy, np. `http://localhost:8080/**`.
6. W **Authentication → Providers → Email** pozostaw włączone logowanie e-mail/hasło. Dla rejestracji z weryfikacją e-mail skonfiguruj działającą wysyłkę poczty (SMTP w Supabase); wbudowana wysyłka testowa ma limity.
7. Uruchom lokalnie `python -m http.server 8080` i otwórz `http://localhost:8080`, albo opublikuj repozytorium przez GitHub Pages.
8. Po pierwszym logowaniu aplikacja zapyta, czy przenieść lokalne postępy do konta. Przy zmianie konta lokalna kopia robocza jest zachowywana przed pobraniem danych zalogowanego użytkownika.

Dostępne formularze: **Zaloguj się**, **Zarejestruj się** (e-mail + hasło, minimum 10 znaków), **Nie pamiętam hasła** oraz formularz ustawienia nowego hasła z linku e-mail. W przypadku zapomnianego hasła Supabase wysyła link resetujący — wiadomość e-mail musi być skonfigurowana po stronie projektu.

### Publikacja na GitHub Pages

W repozytorium znajduje się workflow `.github/workflows/pages.yml`. Po wypchnięciu plików do gałęzi `main` włącz w ustawieniach repozytorium **Settings → Pages → Build and deployment → GitHub Actions**. W URL Configuration Supabase dodaj otrzymany adres `https://<użytkownik>.github.io/<repozytorium>/` do Redirect URLs. Aktualizacja `supabase-config.js` przed publikacją jest wymagana; do publicznego repo trafia tylko anon/public key, nigdy `service_role`.

### Co nie jest jeszcze skonfigurowane

Nie utworzono projektu Supabase ani nie wstawiono jego adresu/klucza — konta nie będą działały, dopóki nie uzupełnisz `supabase-config.js` i nie wykonasz SQL. Nie podłączono też jeszcze repozytorium GitHub; aktualnie dostępne na połączonym koncie repozytorium dotyczy innego projektu „Głos Uczniów” i nie powinno być użyte do mieszania kodu dwóch aplikacji.
