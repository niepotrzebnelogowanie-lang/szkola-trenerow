# Źródła redakcyjne

Treści aplikacji zostały opracowane jako autorskie syntezy szkoleniowe. Odwołania do publicznych źródeł służą uzupełnieniu i kontekstowi, a nie oznaczają afiliacji ani poparcia ze strony tych organizacji.

1. **UEFA — Coaching licences.** Oficjalny przegląd dyplomów i ogólnych kryteriów kursów.
   https://www.uefa.com/development/coaches/uefa-coaching-licences/
2. **UEFA — Champions League performance insights: the importance of in-game management.** Kontekst analizy budowania gry Manchesteru City przeciwko blokowi 4-4-2 Realu Madryt.
   https://www.uefa.com/uefachampionsleague/news/028c-1ab88d1dbff7-a3a7970115ff-1000--champions-league-performance-insights-the-importance-of-in-/
3. **Premier League — How Guardiola and Klopp's tactics have continuously evolved.** Kontekst ewolucji podejść do kontroli posiadania, pressingu i przejść.
   https://www.premierleague.com/en/news/3791815
4. **UEFA — UEFA Coaching Convention 2025.** Dokument dotyczący konwencji trenerskiej i ram kwalifikacji.
   https://documents.uefa.com/api/khub/documents/wy9vGhmNiib2WOQk1txZxg/content

Analizy w aplikacji dotyczą powtarzalnych mechanizmów gry, są uproszczonymi materiałami dydaktycznymi i nie stanowią pełnej rekonstrukcji planu meczowego danego trenera. Przed publikacją komercyjną warto wykonać ekspercką weryfikację wszystkich treści oraz aktualnych wymogów federacji.

## Rozszerzenie biblioteki analiz — 1.3

Biblioteka została rozbudowana do 24 studiów przypadku, obejmujących trenerów i modele gry z ponad 20 kontekstów klubowych. Opisy mechanizmów są autorskimi syntezami dydaktycznymi, a nie cytatami z raportów ani twierdzeniem, że dany trener stosuje każdy opisany mechanizm w każdym meczu. Przed analizą konkretnego spotkania należy sprawdzić skład, sezon, rywala, wynik i materiał źródłowy.

- UEFA, ranking klubowy i kontekst współczynników (stan na koniec 2025): https://www.uefa.com/uefachampionsleague/news/02a0-1f8b9164ba92-1dd42564c706-1000--uefa-rankings-2025-which-teams-and-nations-are-on-top/
- UEFA, zespoły Ligi Mistrzów 2026/27: https://www.uefa.com/uefachampionsleague/news/02a8-2171a88881a0-c70193b972c6-1000--meet-the-2026-27-champions-league-league-phase-teams/
- UEFA, raporty techniczne sezonu 2025/26: https://www.uefa.com/uefachampionsleague/news/02a6-20d7f1dee946-a9e92820d7fc-1000--read-the-official-2025-26-technical-reports/
- Premier League, menedżerowie sezonu 2026/27: https://www.premierleague.com/en/news/4679012/manager-line-up-complete-for-202627-season
- Oficjalna historia trenerów Realu Madryt: https://www.realmadrid.com/en-US/the-club/history/football/first-team/coaches

Uwaga: lista klubów nie jest deklaracją obiektywnego rankingu „20 najlepszych klubów świata”. To wybór czołowych europejskich środowisk piłkarskich do nauki. Składy sztabów i trenerzy zmieniają się; w analizie rzeczywistego meczu zawsze weryfikuj aktualny okres i klub. Dwa wpisy oznaczone „model” są studiami taktycznymi, nie potwierdzeniem bieżącego zatrudnienia.


## Profile taktyczne dodane do biblioteki

Studia dotyczące Andoniego Iraoli, Xabiego Alonso, Liama Roseniora, Enzo Mareski i Simone Inzaghiego są syntezami dydaktycznymi ogólnych mechanizmów gry. Nie przypisują szczegółowych sekwencji do konkretnego meczu bez materiału wideo i danych meczowych. Użytkownik powinien weryfikować hipotezy na podstawie nagrań oraz kontekstu sezonu. Oficjalne strony klubów mogą pomóc w ustaleniu kontekstu, nie są automatycznie źródłem potwierdzającym każdą interpretację taktyczną.


## Analizy taktyczne — notatka redakcyjna

Rozbudowane profile trenerów w wersji 1.4 są syntezami dydaktycznymi opartymi na powszechnie stosowanych koncepcjach taktycznych. Formacje są opisywane jako możliwe/typowe struktury zależne od sezonu, przeciwnika i personelu, a nie jako stałe ustawienie we wszystkich meczach. Dla pełnej analizy meczowej dodaj osobno datę, przeciwnika, nagranie/licencjonowane źródło i znaczniki czasu.


## Testy do wszystkich analiz trenerów — wersja 1.5

Sprawdziany i informacja zwrotna są autorskimi elementami dydaktycznymi wyprowadzonymi z odpowiedniego studium przypadku. Nie są oficjalnymi testami UEFA ani certyfikowaną oceną trenerską. Ocena tekstu bazuje na jawnej rubryce i wzorcach językowych. Ocena tablicy taktycznej sprawdza kompletność wykonania (przesunięcie zawodnika, strzałki i uzasadnienie), a nie semantyczną trafność ustawienia. Pełna ocena taktyczna wymaga analizy przez człowieka, kontekstu meczu i — w przypadku studiów konkretnych spotkań — materiałów wideo z prawami do wykorzystania.
