/* Public Supabase client configuration. Never put a service_role key here. */
window.SZKOLA_SUPABASE_CONFIG = {
  url: "https://YOUR_PROJECT_ID.supabase.co",
  anonKey: "YOUR_SUPABASE_ANON_KEY"
};
